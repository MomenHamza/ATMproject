
package loginform;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class LOGG {
    public void match(String n,int p) throws SQLException{
        String name="root";
        String password="";
        String con_link="jdbc:mysql://localhost/login form";
        Connection con =(Connection) DriverManager.getConnection(con_link, name, password);
        
        Statement stat=(Statement) con.createStatement();
        String SQL="SELECT * FROM atm_information";
        ResultSet rs=stat.executeQuery(SQL);
        while (rs.next()) {            
            if(rs.getString("name").equals(n)){
                if (p==rs.getInt("password")) {
                    System.out.println("done");
                }
            }
            //System.out.println("your name is"+rs.getString("name"));
            
        }
        
        con.close();
    }
    
}
