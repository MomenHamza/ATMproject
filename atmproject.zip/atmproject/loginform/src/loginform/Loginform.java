
package loginform;

import com.mysql.jdbc.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.print.DocFlavor;



public class Loginform {
    public static void main(String[] args) throws SQLException {
        
    }
    
}
