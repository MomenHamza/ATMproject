
package loginform;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

 
public class Log extends javax.swing.JFrame {
    controller controller=new controller();

    public Log() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        titleP = new javax.swing.JPanel();
        loginTitle_B = new javax.swing.JLabel();
        X_B = new javax.swing.JLabel();
        _B = new javax.swing.JLabel();
        loginPage = new javax.swing.JPanel();
        login_L = new javax.swing.JLabel();
        newAcc_L = new javax.swing.JLabel();
        loginp = new javax.swing.JPanel();
        PasswordF = new javax.swing.JPasswordField();
        usernameF = new javax.swing.JTextField();
        loginB = new javax.swing.JButton();
        usernameL = new javax.swing.JLabel();
        passwordL = new javax.swing.JLabel();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Atm login");
        setBackground(new java.awt.Color(51, 0, 51));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        titleP.setBackground(new java.awt.Color(248, 148, 6));

        loginTitle_B.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        loginTitle_B.setForeground(new java.awt.Color(255, 255, 255));
        loginTitle_B.setText("login");

        X_B.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        X_B.setForeground(new java.awt.Color(255, 255, 255));
        X_B.setText("X");
        X_B.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        X_B.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                X_BMouseClicked(evt);
            }
        });

        _B.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        _B.setForeground(new java.awt.Color(255, 255, 255));
        _B.setText("_");
        _B.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        _B.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _BMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout titlePLayout = new javax.swing.GroupLayout(titleP);
        titleP.setLayout(titlePLayout);
        titlePLayout.setHorizontalGroup(
            titlePLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(titlePLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(loginTitle_B)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 565, Short.MAX_VALUE)
                .addComponent(_B)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(X_B)
                .addContainerGap())
        );
        titlePLayout.setVerticalGroup(
            titlePLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(titlePLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(titlePLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(loginTitle_B)
                    .addComponent(X_B))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(titlePLayout.createSequentialGroup()
                .addComponent(_B)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(titleP, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 690, 50));

        loginPage.setBackground(new java.awt.Color(44, 62, 80));

        login_L.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        login_L.setForeground(new java.awt.Color(255, 255, 255));
        login_L.setText("     I have account");
        login_L.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(248, 148, 6)));
        login_L.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        login_L.setName(""); // NOI18N
        login_L.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                login_LMouseClicked(evt);
            }
        });

        newAcc_L.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        newAcc_L.setForeground(new java.awt.Color(255, 255, 255));
        newAcc_L.setText("  Create new account");
        newAcc_L.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(248, 148, 6)));
        newAcc_L.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        newAcc_L.setMaximumSize(new java.awt.Dimension(129, 21));
        newAcc_L.setMinimumSize(new java.awt.Dimension(129, 21));
        newAcc_L.setName(""); // NOI18N
        newAcc_L.setPreferredSize(new java.awt.Dimension(129, 21));
        newAcc_L.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                newAcc_LMouseClicked(evt);
            }
        });

        loginp.setBackground(new java.awt.Color(44, 62, 80));
        loginp.setFont(new java.awt.Font("Century Gothic", 0, 11)); // NOI18N

        PasswordF.setBackground(new java.awt.Color(44, 62, 80));
        PasswordF.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        PasswordF.setForeground(new java.awt.Color(255, 255, 255));
        PasswordF.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PasswordF.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        PasswordF.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        PasswordF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PasswordFActionPerformed(evt);
            }
        });

        usernameF.setBackground(new java.awt.Color(44, 62, 80));
        usernameF.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        usernameF.setForeground(new java.awt.Color(228, 241, 254));
        usernameF.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        usernameF.setToolTipText("");
        usernameF.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        usernameF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usernameFActionPerformed(evt);
            }
        });

        loginB.setBackground(new java.awt.Color(34, 167, 240));
        loginB.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        loginB.setForeground(new java.awt.Color(255, 255, 255));
        loginB.setText("login ");
        loginB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginBActionPerformed(evt);
            }
        });

        usernameL.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        usernameL.setForeground(new java.awt.Color(236, 240, 241));
        usernameL.setText("User Name ");

        passwordL.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        passwordL.setForeground(new java.awt.Color(236, 240, 241));
        passwordL.setText("password  ");

        javax.swing.GroupLayout loginpLayout = new javax.swing.GroupLayout(loginp);
        loginp.setLayout(loginpLayout);
        loginpLayout.setHorizontalGroup(
            loginpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginpLayout.createSequentialGroup()
                .addContainerGap(117, Short.MAX_VALUE)
                .addGroup(loginpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, loginpLayout.createSequentialGroup()
                        .addGroup(loginpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(loginpLayout.createSequentialGroup()
                                .addComponent(passwordL)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(PasswordF, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(loginpLayout.createSequentialGroup()
                                .addComponent(usernameL, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(usernameF, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(30, 30, 30))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, loginpLayout.createSequentialGroup()
                        .addComponent(loginB, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(196, 196, 196))))
        );
        loginpLayout.setVerticalGroup(
            loginpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginpLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(loginpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(usernameF, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(usernameL, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(loginpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(passwordL, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PasswordF, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(loginB, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(84, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout loginPageLayout = new javax.swing.GroupLayout(loginPage);
        loginPage.setLayout(loginPageLayout);
        loginPageLayout.setHorizontalGroup(
            loginPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginPageLayout.createSequentialGroup()
                .addContainerGap(130, Short.MAX_VALUE)
                .addGroup(loginPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, loginPageLayout.createSequentialGroup()
                        .addComponent(newAcc_L, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(login_L, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(88, 88, 88))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, loginPageLayout.createSequentialGroup()
                        .addComponent(loginp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(60, 60, 60))))
        );
        loginPageLayout.setVerticalGroup(
            loginPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginPageLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(loginPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newAcc_L, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(login_L, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(loginp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        getContentPane().add(loginPage, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 690, 390));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void usernameFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernameFActionPerformed

    }//GEN-LAST:event_usernameFActionPerformed

    private void loginBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginBActionPerformed
        try {
            controller.login(usernameF.getText(),PasswordF.getText());
        } catch (SQLException ex) {
            Logger.getLogger(Log.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_loginBActionPerformed

    private void PasswordFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PasswordFActionPerformed

    }//GEN-LAST:event_PasswordFActionPerformed

    private void X_BMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_X_BMouseClicked
       System.exit(0);
    }//GEN-LAST:event_X_BMouseClicked

    private void _BMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__BMouseClicked
       this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event__BMouseClicked

    private void newAcc_LMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_newAcc_LMouseClicked
       signup sgn = new signup();
       sgn.setVisible(true);
       sgn.pack();
       sgn.setLocationRelativeTo(null);
       sgn.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       this.dispose();
    }//GEN-LAST:event_newAcc_LMouseClicked

    private void login_LMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_login_LMouseClicked
       
    }//GEN-LAST:event_login_LMouseClicked

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Log.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Log.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Log.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Log.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Log().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField PasswordF;
    private javax.swing.JLabel X_B;
    private javax.swing.JLabel _B;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton loginB;
    private javax.swing.JPanel loginPage;
    private javax.swing.JLabel loginTitle_B;
    private javax.swing.JLabel login_L;
    private javax.swing.JPanel loginp;
    private javax.swing.JLabel newAcc_L;
    private javax.swing.JLabel passwordL;
    private javax.swing.JPanel titleP;
    private javax.swing.JTextField usernameF;
    private javax.swing.JLabel usernameL;
    // End of variables declaration//GEN-END:variables
}
