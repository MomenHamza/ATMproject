
package loginform;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class controller {
    public void login(String username,String pass) throws SQLException{
        String name="root";
        String password="";
        String con_link="jdbc:mysql://localhost/login form";
        Connection con =(Connection) DriverManager.getConnection(con_link, name, password);
        PreparedStatement preparestatment = null;
        Statement stat=(Statement) con.createStatement();
        String SQL="SELECT * FROM atm_information";
        ResultSet rs=stat.executeQuery(SQL);
        
        while (rs.next()) {            
            if(rs.getString("name").equals(username) && rs.getString("password").equals(pass)) {
                    System.out.println("done");
                }
            }  
         con.close();
    }
    public void signup(String username,String pass) throws SQLException{
        String name="root";
        String password="";
        String con_link="jdbc:mysql://localhost/login form";
        Connection con =(Connection) DriverManager.getConnection(con_link, name, password);
        PreparedStatement preparestatment = null;
        Statement stat=(Statement) con.createStatement();
        String SQL="SELECT * FROM atm_information";
        ResultSet rs=stat.executeQuery(SQL);
        
        con.prepareStatement("INSERT INTO `atm_information` (`name`, `password`) VALUES ('"+username+"', '"+pass+"');").executeUpdate();
          
                       System.out.println("done");                 
         con.close();
    }
}
    
    

