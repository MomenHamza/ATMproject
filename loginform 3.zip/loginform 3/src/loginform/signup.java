/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginform;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author amr mostafa
 */

public class signup extends javax.swing.JFrame {
        
    controller controller=new controller();
    
    public signup() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        feedbackL = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        titleP = new javax.swing.JPanel();
        title = new javax.swing.JLabel();
        XB = new javax.swing.JLabel();
        _B = new javax.swing.JLabel();
        signupPage = new javax.swing.JPanel();
        loginL = new javax.swing.JLabel();
        newAccL = new javax.swing.JLabel();
        infoP = new javax.swing.JPanel();
        PasswordF = new javax.swing.JPasswordField();
        usernameF = new javax.swing.JTextField();
        signupB = new javax.swing.JButton();
        usernameL = new javax.swing.JLabel();
        passwordL = new javax.swing.JLabel();
        emailL = new javax.swing.JLabel();
        emailF = new javax.swing.JTextField();
        cardnum = new javax.swing.JLabel();
        cardnumF = new javax.swing.JTextField();
        pinL = new javax.swing.JLabel();
        pinF = new javax.swing.JTextField();

        feedbackL.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        feedbackL.setForeground(new java.awt.Color(255, 255, 255));

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Atm login");
        setBackground(new java.awt.Color(51, 0, 51));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        titleP.setBackground(new java.awt.Color(248, 148, 6));

        title.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        title.setForeground(new java.awt.Color(255, 255, 255));
        title.setText("signup");

        XB.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        XB.setForeground(new java.awt.Color(255, 255, 255));
        XB.setText("X");
        XB.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        XB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                XBMouseClicked(evt);
            }
        });

        _B.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        _B.setForeground(new java.awt.Color(255, 255, 255));
        _B.setText("_");
        _B.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        _B.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _BMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout titlePLayout = new javax.swing.GroupLayout(titleP);
        titleP.setLayout(titlePLayout);
        titlePLayout.setHorizontalGroup(
            titlePLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(titlePLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(title)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 546, Short.MAX_VALUE)
                .addComponent(_B)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(XB)
                .addContainerGap())
        );
        titlePLayout.setVerticalGroup(
            titlePLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(titlePLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(titlePLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(title)
                    .addComponent(XB))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(titlePLayout.createSequentialGroup()
                .addComponent(_B)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(titleP, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 690, 50));

        signupPage.setBackground(new java.awt.Color(44, 62, 80));

        loginL.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        loginL.setForeground(new java.awt.Color(255, 255, 255));
        loginL.setText("     I have account");
        loginL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(248, 148, 6)));
        loginL.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        loginL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                loginLMouseClicked(evt);
            }
        });

        newAccL.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        newAccL.setForeground(new java.awt.Color(255, 255, 255));
        newAccL.setText("  Create new account");
        newAccL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(248, 148, 6)));
        newAccL.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        newAccL.setMaximumSize(new java.awt.Dimension(129, 21));
        newAccL.setMinimumSize(new java.awt.Dimension(129, 21));
        newAccL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                newAccLMouseClicked(evt);
            }
        });

        infoP.setBackground(new java.awt.Color(44, 62, 80));

        PasswordF.setBackground(new java.awt.Color(44, 62, 80));
        PasswordF.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        PasswordF.setForeground(new java.awt.Color(255, 255, 255));
        PasswordF.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PasswordF.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        PasswordF.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        PasswordF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PasswordFActionPerformed(evt);
            }
        });

        usernameF.setBackground(new java.awt.Color(44, 62, 80));
        usernameF.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        usernameF.setForeground(new java.awt.Color(228, 241, 254));
        usernameF.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        usernameF.setToolTipText("");
        usernameF.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        usernameF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usernameFActionPerformed(evt);
            }
        });

        signupB.setBackground(new java.awt.Color(34, 167, 240));
        signupB.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        signupB.setForeground(new java.awt.Color(255, 255, 255));
        signupB.setText("SignUp");
        signupB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signupBActionPerformed(evt);
            }
        });

        usernameL.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        usernameL.setForeground(new java.awt.Color(236, 240, 241));
        usernameL.setText("User Name ");

        passwordL.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        passwordL.setForeground(new java.awt.Color(236, 240, 241));
        passwordL.setText("password  ");

        emailL.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        emailL.setForeground(new java.awt.Color(236, 240, 241));
        emailL.setText("Email");

        emailF.setBackground(new java.awt.Color(44, 62, 80));
        emailF.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        emailF.setForeground(new java.awt.Color(228, 241, 254));
        emailF.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        emailF.setToolTipText("");
        emailF.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        emailF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailFActionPerformed(evt);
            }
        });

        cardnum.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        cardnum.setForeground(new java.awt.Color(236, 240, 241));
        cardnum.setText("card number");

        cardnumF.setBackground(new java.awt.Color(44, 62, 80));
        cardnumF.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        cardnumF.setForeground(new java.awt.Color(228, 241, 254));
        cardnumF.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cardnumF.setToolTipText("");
        cardnumF.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        cardnumF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cardnumFActionPerformed(evt);
            }
        });

        pinL.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        pinL.setForeground(new java.awt.Color(236, 240, 241));
        pinL.setText("PIN");

        pinF.setBackground(new java.awt.Color(44, 62, 80));
        pinF.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        pinF.setForeground(new java.awt.Color(228, 241, 254));
        pinF.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pinF.setToolTipText("");
        pinF.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        pinF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pinFActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout infoPLayout = new javax.swing.GroupLayout(infoP);
        infoP.setLayout(infoPLayout);
        infoPLayout.setHorizontalGroup(
            infoPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(infoPLayout.createSequentialGroup()
                .addGroup(infoPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(infoPLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(infoPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(infoPLayout.createSequentialGroup()
                                .addGroup(infoPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(passwordL, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(usernameL, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(26, 26, 26)
                                .addGroup(infoPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(PasswordF)
                                    .addComponent(usernameF, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(infoPLayout.createSequentialGroup()
                                .addGroup(infoPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(emailL, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cardnum)
                                    .addComponent(pinL))
                                .addGap(18, 18, 18)
                                .addGroup(infoPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(emailF)
                                    .addComponent(cardnumF, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(pinF, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(infoPLayout.createSequentialGroup()
                        .addGap(165, 165, 165)
                        .addComponent(signupB, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(47, Short.MAX_VALUE))
        );
        infoPLayout.setVerticalGroup(
            infoPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(infoPLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(infoPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(usernameF, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(usernameL, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(infoPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PasswordF, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(passwordL, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(infoPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(emailF, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(emailL, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(infoPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cardnumF, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cardnum, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(infoPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(pinF, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pinL, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(signupB, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout signupPageLayout = new javax.swing.GroupLayout(signupPage);
        signupPage.setLayout(signupPageLayout);
        signupPageLayout.setHorizontalGroup(
            signupPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(signupPageLayout.createSequentialGroup()
                .addContainerGap(231, Short.MAX_VALUE)
                .addGroup(signupPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(infoP, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, signupPageLayout.createSequentialGroup()
                        .addComponent(newAccL, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(loginL, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(88, 88, 88))))
        );
        signupPageLayout.setVerticalGroup(
            signupPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(signupPageLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(signupPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newAccL, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(loginL, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(infoP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(signupPage, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 690, 380));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void XBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_XBMouseClicked
       System.exit(0);
    }//GEN-LAST:event_XBMouseClicked

    private void _BMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__BMouseClicked
       this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event__BMouseClicked

    private void loginLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loginLMouseClicked
       Log lg = new Log();
       lg.setVisible(true);
       lg.pack();
       lg.setLocationRelativeTo(null);
       lg.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       this.dispose();
    }//GEN-LAST:event_loginLMouseClicked

    private void newAccLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_newAccLMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_newAccLMouseClicked

    private void PasswordFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PasswordFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PasswordFActionPerformed

    private void usernameFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernameFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usernameFActionPerformed

    private void signupBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signupBActionPerformed
        try {
            feedbackL.setText("YOUR ACCOUNT ADDED SUCCESFULLY");
            controller.signup(usernameF.getText(), PasswordF.getText());
        } catch (SQLException ex) {
            Logger.getLogger(signup.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_signupBActionPerformed

    private void emailFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailFActionPerformed

    private void cardnumFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cardnumFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cardnumFActionPerformed

    private void pinFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pinFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pinFActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new signup().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField PasswordF;
    private javax.swing.JLabel XB;
    private javax.swing.JLabel _B;
    private javax.swing.JLabel cardnum;
    private javax.swing.JTextField cardnumF;
    private javax.swing.JTextField emailF;
    private javax.swing.JLabel emailL;
    private javax.swing.JLabel feedbackL;
    private javax.swing.JPanel infoP;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel loginL;
    private javax.swing.JLabel newAccL;
    private javax.swing.JLabel passwordL;
    private javax.swing.JTextField pinF;
    private javax.swing.JLabel pinL;
    private javax.swing.JButton signupB;
    private javax.swing.JPanel signupPage;
    private javax.swing.JLabel title;
    private javax.swing.JPanel titleP;
    private javax.swing.JTextField usernameF;
    private javax.swing.JLabel usernameL;
    // End of variables declaration//GEN-END:variables
}
